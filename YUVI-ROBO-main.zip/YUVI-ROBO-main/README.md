<p align="center">
  <img src="https://te.legra.ph/file/12c4b71de20e58a3c31a4.jpg">
</p>

<h4><p align="center"> YUVI ROBO </p></h4>

<p align="center">YUVI ROBO is a modular bot running on python3 with anime theme and have a lot features.</p>

<p align="center">
<a href="https://t.me/YUVIROBO"> <img src="https://img.shields.io/badge/YUVI-Robo-blue?&logo=telegram" alt="Emiko on Telegram" /> </a><br>
<a href="https://t.me/DAMAGED_GUY"> <img src="https://img.shields.io/badge/Maintained-YUVI-yellow.svg" alt="Maintenance" /> </a><br>
### TUTORIAL

- First fork this repository.
- Then change the deploy link bellow.
- This step must be doing because mine link is violates the salesforce acceptable use.
- You can just change the name of github on deploy link and done, the repos able to deploy on heroku.
- Full Tutorial - [![Full Tutorial](https://img.shields.io/badge/Watch%20Now-blue)](https://youtu.be/GMaYMYhf_Vk)

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/YUVInaira/YUVIRobo"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

```
This Bot is Created by YUVI ROBO, If your kanging this without fork at least give a credit to get a smile of my hard work. 
- YUVI
```

### Support
<p>
<a href="https://t.me/DAMAGED_GUY"> <img src="https://img.shields.io/badge/YUVI-DEV-blue?&logo=telegram" alt="Sena on Telegram" /> </a><br>
<a href="https://t.me/YUVIROBO"> <img src="https://img.shields.io/badge/Update-Channel-blue?&logo=telegram" alt="Update Channel" /> </a><br>
</p>

## Credit 

• [YUVI](https://t.me/DAMAGED_GUY)

