__mod_name__ = "Musicplayer"

__help__ = """
──「 Music stream 」──              

❂ /play (query or reply audio) to playing music from yourube or your audio telegram.
❂ /playlist (choose option) for playing your personal playlist or group playlist.

• Admins only

❂ /auth - Add to authorized users.
❂ /unauth - Canceling or deleting from authorized users list.
❂ /msettings - To open panel settings on musicplayer.
❂ /setadmin - To set all command only for admins.
❂ /setmember - Set all command for all members.
❂ /vol (range 1-200) - To set volume on voice calls.

NOTE : DON'T SPAMMING AT REQUEST SONG OR VIDEO...
"""
